<?php
require_once 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    
    if (empty($username) || empty($password) || empty($confirm_password)) {
        $error = "All fields are required!";
    } else {
        // Validate password requirements
        if (strlen($password) < 8) {
            $error = "Password must be at least 8 characters long!";
        } elseif (!preg_match('/[A-Z]/', $password)) {
            $error = "Password must contain at least one uppercase letter!";
        } elseif (!preg_match('/[0-9]/', $password)) {
            $error = "Password must contain at least one number!";
        } elseif (!preg_match('/[-_=+]/', $password)) {
            $error = "Password must contain at least one special character (-, _, =, or +)!";
        } elseif ($password !== $confirm_password) {
            $error = "Passwords do not match!";
        } else {
            try {
                $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (:username, :password)");
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt->bindParam(':username', $username);
                $stmt->bindParam(':password', $hashed_password);
                $stmt->execute();
                $success = "Registration successful! <a href='login.php'>Login here</a>";
            } catch(PDOException $e) {
                $error = "Error: Username already exists!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register - Mountain Haven</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            font-family: 'Open Sans', sans-serif;
            background: url('mountain.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #333;
        }
        .container {
            max-width: 400px;
            margin: 100px auto;
            padding: 30px;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 20px;
        }
        input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 1em;
        }
        .btn {
            width: 100%;
            padding: 12px;
            background: #ff6b6b;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background 0.3s;
        }
        .btn:hover {
            background: #e55b5b;
        }
        .message, .error {
            text-align: center;
            margin-top: 10px;
        }
        .message { color: #27ae60; }
        .error { color: #e74c3c; }
        .links {
            text-align: center;
            margin-top: 15px;
        }
        .links a {
            color: #007bff;
            text-decoration: none;
        }
        .links a:hover {
            text-decoration: underline;
        }
    </style>
    <script>
        function checkPassword() {
            const password = document.querySelector('input[name="password"]').value;
            const requirements = {
                length: password.length >= 8,
                uppercase: /[A-Z]/.test(password),
                number: /[0-9]/.test(password),
                special: /[-_=+]/.test(password)
            };

            let missing = [];
            if (!requirements.length) missing.push("at least 8 characters");
            if (!requirements.uppercase) missing.push("one uppercase letter");
            if (!requirements.number) missing.push("one number");
            if (!requirements.special) missing.push("one special character (-, _, =, or +)");

            if (missing.length > 0) {
                alert("Your password needs to include: " + missing.join(", "));
                return false;
            }
            return true;
        }

        // Trigger check when password field loses focus
        document.addEventListener('DOMContentLoaded', function() {
            const passwordInput = document.querySelector('input[name="password"]');
            passwordInput.addEventListener('blur', checkPassword);
        });
    </script>
</head>
<body>
    <div class="container">
        <h2>Register for my website</h2>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <input type="submit" value="Register" class="btn">
        </form>
        <?php if (isset($success)) echo "<p class='message'>$success</p>"; ?>
        <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        <div class="links">
            <p>Already have an account? <a href="login.php">Login here</a></p>
        </div>
    </div>
</body>
</html>