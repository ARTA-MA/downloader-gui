<!DOCTYPE html>
<html lang="en">
<head>
    <title>Mountain Haven</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            font-family: 'Open Sans', sans-serif;
            background: url('mountain.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #333;
        }
        header {
            padding: 20px;
            background: rgba(255, 255, 255, 0.8);
            text-align: right;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .btn {
            padding: 12px 25px;
            margin: 0 10px;
            text-decoration: none;
            color: white;
            background: #ff6b6b; /* Warm pink-orange inspired by sunset */
            border-radius: 5px;
            transition: background 0.3s;
        }
        .btn:hover {
            background: #e55b5b;
        }
        main {
            padding: 100px 20px;
            text-align: center;
            color: white;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }
        main h1 {
            font-size: 3em;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <header>
        <a href="login.php" class="btn">Login</a>
        <a href="register.php" class="btn">Register</a>
    </header>
    <main>
        <h1>Welcome to my website</h1>
        <p>You can log in and register in my site.</p>
    </main>
</body>
</html>